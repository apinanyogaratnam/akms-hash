AKMS Hash

An API Key hashing library.
